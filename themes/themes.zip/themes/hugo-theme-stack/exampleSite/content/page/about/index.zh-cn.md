---
title: 关于
menu:
    main: 
        weight: -90
        params:
            icon: user
---

This is a test page for i18n support.